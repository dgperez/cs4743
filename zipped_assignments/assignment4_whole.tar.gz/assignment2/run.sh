java -cp ./bin core.MyDemo
