UTSA - CS4743
Applied Software Engineering
Professor Dr. Mark Robinson

These are the assignments and group projects for the Spring 2014 semester, stored for posterity, reference, and redundancy.

Group Members:
1) Josh Smith
2) Kyle Haley
