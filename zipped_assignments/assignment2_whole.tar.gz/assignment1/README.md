Assignment 1

Working Record: This represents a working copy of the assignment. Most work from assignments in the future will be done in here with regards to this project. You can track these changes in the commit history.

Assignment 1:

Create an inventory/part list view coupled to a detail view that will represent the individual inventory item's editable properties. Show all properties of the item within each entry on the Inventory List view.

First project representing work on MVC.

Assignment 2: 

All changes from Assignment 2 to this directory take place after the tag "assignment2". 

Given a series of Change Requests and storing the project in git (this project was always in git), each team member will complete a separate change request on their own branch. Team members will switch off ownership of the master repo to merge completed branches into the master branch.


