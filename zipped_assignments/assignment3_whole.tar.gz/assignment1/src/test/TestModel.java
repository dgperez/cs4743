package test;

import static org.junit.Assert.*;
import main.model.Inventory;
import main.model.Item;
import org.junit.Test;

public class TestModel {

	@Test
	public void test() {
		
	}
	
}
