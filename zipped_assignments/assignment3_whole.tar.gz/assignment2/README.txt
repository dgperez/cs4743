Assignment 2:

This represents the first part of Assignment 2. All changes for Assignment 2 start after the tag "assignment2". This contains all the file changes for the first part of Assignment 2. All subsequent changes in part two, which required a modification of Assignment 1 via Change Requests, are in subfolder 'assignment1'.
