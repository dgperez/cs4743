javac src/core/*.java -d ./bin
