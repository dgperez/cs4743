package core;

public class MyDemo {

	public MyDemo() {
		System.out.println("Hello world!");
	}
	
	public static void main(String [] args) {
		MyDemo app = new MyDemo();
	}
}